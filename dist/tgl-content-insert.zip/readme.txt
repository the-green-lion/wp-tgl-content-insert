=== Plugin Name ===
Contributors: thegreenlion
Tags: TGL
Requires at least: 4.0
Tested up to: 4.7
Stable tag: trunk
License: MIT
License URI: https://opensource.org/licenses/MIT

Gives you an easy way to add The Green Lion's program descriptions to your website. No more copy-paste, no more keeping them updated by hand.

== Description ==

Find the full description on our [Github Repository](https://github.com/the-green-lion/wp-tgl-content-insert)

== Installation ==

Find the full description on our [Github Repository](https://github.com/the-green-lion/wp-tgl-content-insert)

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==

= 0.5 =
* Initial release. Handle with caution.

== Upgrade Notice ==

= 0.5 =
Initial release. Handle with caution.